A Pen created at CodePen.io. You can find this one at https://codepen.io/riktar/pen/dPRgOq.

 text-shadow experiment for create a neon type text
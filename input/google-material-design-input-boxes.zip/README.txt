A Pen created at CodePen.io. You can find this one at https://codepen.io/sevilayha/pen/IdGKH.

 A CSS experiment to recreate the Google Material Design Polymer input boxes in CSS.

Tutorial Here: [scotch.io](http://scotch.io/tutorials/css/google-material-design-input-boxes-in-css3)